using System;

namespace WorkflowEngine.Models
{
    public class StateTransition
    {
        public string ActionId { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
